package com.example.springproject.entity;

import lombok.*;
import lombok.experimental.FieldDefaults;
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class User {

    long id;
    String name;
    int age;

}
