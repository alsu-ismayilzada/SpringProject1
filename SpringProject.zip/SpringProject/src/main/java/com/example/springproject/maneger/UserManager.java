package com.example.springproject.maneger;
import com.example.springproject.entity.User;
import com.example.springproject.service.UserService;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
@Component
public class UserManager implements UserService {
    private static List<User> list = new ArrayList<>();

    static{
        list.add(new User(1,"Alsu Ismayilzade",20));
        list.add(new User(2,"Ugur Kerimov",20));
        list.add(new User(3,"Sebnem Eliyeva",19));
        list.add(new User(4,"Rufet Huseynov",19));
    }
    @Override
    public List<User> findAll() {
        return list;
    }

    @Override
    public User findById(int id) {
        return list.get(id);
    }

    @Override
    public void addUser(User user) {
     list.add(user);
    }

    @Override
    public void deleteUser(int id) {
        list.remove(id);
    }
}
